package com.example.mytunes.model;

import java.io.File;

public class FileRef {

    private File fil;

    public FileRef(File fil){
        this.fil = fil;
    }

    public void initialize(){
        File f0 = new File("/usr/local/indsæt path til fil");
        File f1 = new File("/usr/local/indsæt path til fil");
        File f2 = new File("/usr/local/indsæt path til fil");
        File f3 = new File("/usr/local/indsæt path til fil");
        File f4 = new File("/usr/local/indsæt path til fil");
        File f5 = new File("/usr/local/indsæt path til fil");
        File f6 = new File("/usr/local/indsæt path til fil");
    }

}
